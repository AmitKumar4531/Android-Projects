package com.example.lighteningapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;
import java.util.Map;

public class UserInputActivity extends AppCompatActivity {

      EditText windspeed;
     EditText cloudcolor;
      EditText temperature;
     Button predictbutton;
     DatabaseReference databaseuserinputs;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_input);
        databaseuserinputs= FirebaseDatabase.getInstance().getReferenceFromUrl("https://ligthening-application.firebaseio.com/");
        Toast.makeText(UserInputActivity.this,"Welcome to User Input Activity",Toast.LENGTH_LONG).show();
        windspeed=(EditText)findViewById(R.id.windspeed);
        cloudcolor=(EditText)findViewById(R.id.cloudcolor);
        temperature=(EditText)findViewById(R.id.temperature);
        predictbutton=findViewById(R.id.predictbutton);
        predictbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               addUserActivityData();

            }
        });
    }

    public void addUserActivityData()
    {

         String windspeed_txt=windspeed.getText().toString();
         String cloudcolor_txt=cloudcolor.getText().toString();
         String temperature_txt=temperature.getText().toString();
         if(!TextUtils.isEmpty(windspeed_txt) & !TextUtils.isEmpty(cloudcolor_txt) & ! TextUtils.isEmpty(temperature_txt))
         {
             String id=databaseuserinputs.push().getKey();

             UserActivityData userdata=new UserActivityData(id,windspeed_txt,cloudcolor_txt,temperature_txt);
             databaseuserinputs.child(id).setValue(userdata).addOnCompleteListener(new OnCompleteListener<Void>() {
                 @Override
                 public void onComplete(@NonNull Task<Void> task) {
                     Toast.makeText(UserInputActivity.this,"Data extracted and send",Toast.LENGTH_LONG).show();

                     Intent intent=new Intent(UserInputActivity.this,RetrieveActivity.class);
                     intent.putExtra("id", id);
                     intent.putExtra("data",1);
                     startActivity(intent);
                 }
             }).addOnFailureListener(new OnFailureListener() {
                 @Override
                 public void onFailure(@NonNull Exception e) {
                     Intent intent=new Intent(UserInputActivity.this,RetrieveActivity.class);
                     intent.putExtra("data",0);
                     startActivity(intent);
                 }
             });


         }
         else
         {
             Toast.makeText(UserInputActivity.this, " Please enter the values  in these three fields: 1. windspeed  2. cloudcolor  3. temperature", Toast.LENGTH_LONG).show();

         }


    }


}