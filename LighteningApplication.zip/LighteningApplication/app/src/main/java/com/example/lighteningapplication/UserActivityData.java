package com.example.lighteningapplication;

public class UserActivityData {

    String userActivityDataId;
    String wind_speed;
    String cloud_color;
    String temperature;

    public UserActivityData()
    {

    }
    public UserActivityData(String userActivityDataId, String wind_speed, String cloud_color, String temperature) {
        this.userActivityDataId = userActivityDataId;
        this.wind_speed = wind_speed;
        this.cloud_color = cloud_color;
        this.temperature = temperature;
    }

    public String getUserActivityDataId() {
        return userActivityDataId;
    }

    public String getWind_speed() {
        return wind_speed;
    }

    public String getCloud_color() {
        return cloud_color;
    }

    public String getTemperature() {
        return temperature;
    }
}
