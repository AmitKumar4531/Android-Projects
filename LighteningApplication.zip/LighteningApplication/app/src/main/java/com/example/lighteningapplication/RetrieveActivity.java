package com.example.lighteningapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.pdf.PdfDocument;
import android.graphics.pdf.PdfRenderer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.ParcelFileDescriptor;
import android.os.StrictMode;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class RetrieveActivity extends AppCompatActivity {
    Button openPdfbtn;
    Button emailPdfbtn;
    FirebaseDatabase database;
    DatabaseReference getdata;
    UserActivityData userdata;
    String email;
    String subject="Today's Lightning Prediction";
    String message="This is the lightening report of Today. Please refer to the attachment";
    String attachmentFile;
    Uri URI = null;
    String file_path;
    private static final int PICK_FROM_GALLERY = 101;
    int columnIndex;
    String file_name_path = "";
    int PERMISSION_ALL = 1;
    String[] PERMISSIONS = {

            android.Manifest.permission.WRITE_EXTERNAL_STORAGE,
            android.Manifest.permission.READ_EXTERNAL_STORAGE,

    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_retrieve);
        Intent intent = getIntent();

        int uploadStatus = intent.getIntExtra("data", 1);
        StrictMode.VmPolicy.Builder builder = new StrictMode.VmPolicy.Builder();
        StrictMode.setVmPolicy(builder.build());
        if (!hasPermissions(RetrieveActivity.this, PERMISSIONS)) {
            ActivityCompat.requestPermissions(RetrieveActivity.this, PERMISSIONS, PERMISSION_ALL);
        }
        openPdfbtn = findViewById(R.id.button3);
        emailPdfbtn = findViewById(R.id.button4);

        database = FirebaseDatabase.getInstance("https://ligthening-application.firebaseio.com/");

        if (uploadStatus == 1) {
            Toast.makeText(RetrieveActivity.this, "Upload Successful ", Toast.LENGTH_LONG).show();
            String iddatabase = intent.getStringExtra("id");
            getdata = database.getReference().child(iddatabase);
            getdata.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    userdata = snapshot.getValue(UserActivityData.class);


                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                    System.out.println("The read failed: " + error.getCode());
                }
            });

        } else {
            Toast.makeText(RetrieveActivity.this, "Upload Failed  ", Toast.LENGTH_LONG).show();
        }

        openPdfbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (uploadStatus == 1) {
                    String contents = "WIND_SPEED" + ":" + userdata.getWind_speed() + "\n" + "CLOUD_COLOR" + ":" + userdata.getCloud_color() + "\n" + "TEMPERATURE" + ":" + userdata.getTemperature() + "";
                    boolean isSaved = convertStringtoPdf(contents);
                    if (isSaved) {
                         viewPdfFile();
                    } else {
                        Toast.makeText(RetrieveActivity.this, "Failed to create the PDF file.", Toast.LENGTH_SHORT).show();
                    }
                }else{
                    Toast.makeText(RetrieveActivity.this, "No data to show.", Toast.LENGTH_SHORT).show();
                }
            }
        });

        emailPdfbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendEmail();
            }
        });
    }

    public boolean convertStringtoPdf(String data) {

        final String fileName = "LighteningReport";
        file_name_path = fileName + ".pdf";

        File file = new File(this.getExternalFilesDir(null).getAbsolutePath(), "pdfsdcard_location");
        if (!file.exists()) {
            file.mkdir();
        }

        try {
            File pdfFile = new File(file.getAbsolutePath() + "/" + file_name_path);
            if (!pdfFile.exists()) {
                pdfFile.createNewFile();
            }


            FileOutputStream fOut = new FileOutputStream(pdfFile);

            DisplayMetrics displayMetrics = new DisplayMetrics();
            getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);

            PdfDocument document = new PdfDocument();
            PdfDocument.PageInfo pageInfo = new
                    PdfDocument.PageInfo.Builder(displayMetrics.widthPixels, displayMetrics.heightPixels, 1).create();
            PdfDocument.Page page = document.startPage(pageInfo);
            Canvas canvas = page.getCanvas();
            Paint paint = new Paint();
            paint.setTextSize(24);

            canvas.drawText(data, 20, 20, paint);
            document.finishPage(page);
            document.writeTo(fOut);
            document.close();
            return true;
        } catch (IOException e) {
            Log.e("error", e.getLocalizedMessage());
        }
        return false;
    }

    public void viewPdfFile() {

        File file = new File(this.getExternalFilesDir(null).getAbsolutePath() + "/pdfsdcard_location/" + file_name_path);
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setDataAndType(Uri.fromFile(file), "application/pdf");
        startActivity(intent);
    }

    public void sendEmail()
    {
        try
        {

            String[] mailto = {"me@gmail.com"};
            Toast.makeText(this, "PDF Location is " ,Toast.LENGTH_LONG).show();
            File file = new File(this.getExternalFilesDir(null).getAbsolutePath() + "/pdfsdcard_location/" + file_name_path);
            Uri uri = Uri.fromFile(file);
            final Intent emailIntent = new Intent(android.content.Intent.ACTION_SEND);
            emailIntent.setType("plain/text");
            emailIntent.putExtra(android.content.Intent.EXTRA_EMAIL, new String[]{email});
            emailIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, subject);
            if (uri != null) {
                emailIntent.putExtra(Intent.EXTRA_STREAM, uri);
            }
            emailIntent.putExtra(android.content.Intent.EXTRA_TEXT, message);
            this.startActivity(Intent.createChooser(emailIntent, "Sending email with Lightening Report..."));

        }
        catch (Throwable t)
        {
            Toast.makeText(this, "Request failed try again: " + t.toString(),Toast.LENGTH_LONG).show();
        }
    }
    
    public static boolean hasPermissions(Context context, String... permissions) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && context != null && permissions != null) {
            for (String permission : permissions) {
                if (ActivityCompat.checkSelfPermission(context, permission) != PackageManager.PERMISSION_GRANTED) {
                    return false;
                }
            }
        }
        return true;
    }
}